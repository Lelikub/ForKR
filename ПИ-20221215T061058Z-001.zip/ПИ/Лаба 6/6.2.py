n = float(input())
f1 = lambda n: n*2
f2 = lambda n: n**2
print(f1(f2(n)))
